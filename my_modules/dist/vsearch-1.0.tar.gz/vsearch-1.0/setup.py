from setuptools import setup

setup(
    name = 'vsearch',
    version = '1.0',
    description = 'search tool',
    author = 'phani',
    author_email = 'balamahendrakorrapati@gmail.com',
    url = 'headfirstlabs.com',
    py_modifier = ['vsearch'],
)    
